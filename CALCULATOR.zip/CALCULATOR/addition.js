

function add(x,y){

let c = x+y;

console.log("Addition :",c);
    
}

module.exports = add;


