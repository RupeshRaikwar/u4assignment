function div(x,y){

    let c = (x/y);

    console.log("Division :",c);

 
}

module.exports = div;