
const sum_is = require("./addition.js");


const sub_is = require("./substract.js");


const multiply = require("./multiplication.js")


const division_is = require("./division.js");

let a = 10;

let b = 25;

sum_is(a,b);

sub_is(a,b);

multiply(a,b);


division_is(a,b);