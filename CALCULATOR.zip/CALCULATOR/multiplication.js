function mult(x,y){

    let c = (x*y);

    console.log("Multiplication :",c);

    // return c ;
}

module.exports = mult;