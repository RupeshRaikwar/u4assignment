
function sub(x,y){

    let c = (x-y);

    console.log("Substraction :",c);
}

// module.exports = { add , sub };

module.exports = sub ;

