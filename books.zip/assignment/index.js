const express = require("express");

const app = express();




app.get("/users", function(req,res){

    res.send("Hello");
});

app.get("/books", function(req,res){

    res.send({
        JAVA:"Learn Java from scrach",
        C:"c/c++",
        Physics:"HC Verma",
        Maths:"RD sharma",
    })
});

app.listen(50000, ()=>{

    console.log("Listen to 5000");
});