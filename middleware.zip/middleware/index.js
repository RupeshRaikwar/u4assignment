const express = require("express");

const app = express();

app.use(singleBook);

app.get("/books", callBook("GameOfThrones"),callBook("HarryPotter"),function(req,res){
    return res.send({ route: "/books", name:req.name  });
});

function callBook(name){
   return function singleBook(req,res,next){

    if((name == "GameOfThrones") || (name = "HarryPotter")){
       
    //    return res.send(req.params.name);
        req.name = name ;
       
        return next();
    }
   }
}
function singleBook(req,res,next){

    if(req.path === "/books"){
        
        

         next();
    }
}
app.listen(5270, (req,res)=>{
    console.log("listening to 5000000000");
})